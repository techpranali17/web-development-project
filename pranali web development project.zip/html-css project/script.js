let timerInterval;
let startTime;
let elapsedTime = 0;
let running = false;

function startTimer() {
  if (!running) {
    startTime = Date.now() - elapsedTime;
    timerInterval = setInterval(updateTimer, 1000);
    running = true;
  }
}

function stopTimer() {
  if (running) {
    clearInterval(timerInterval);
    running = false;
  }
}

function resetTimer() {
  clearInterval(timerInterval);
  elapsedTime = 0;
  updateTimer();
  running = false;
}
function restartTimer() {
    stopTimer(); // Stop the timer if it's running
  resetTimer(); // Reset the timer to zero
  startTimer(); // Start the timer again
  }

function updateTimer() {
  const currentTime = Date.now();
  elapsedTime = currentTime - startTime;
  displayTime(elapsedTime);
}

function displayTime(milliseconds) {
  const totalSeconds = Math.floor(milliseconds / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  
  const formattedTime = padZero(hours) + ':' + padZero(minutes) + ':' + padZero(seconds);
  document.getElementById('timer').textContent = formattedTime;
}

function padZero(number) {
  return (number < 10) ? '0' + number : number;
}
